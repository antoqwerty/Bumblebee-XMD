![cb5dce0c62b8ee5800fcc9a752825aee (1)](https://github.com/user-attachments/assets/3492e82d-a88a-450f-aff9-562a01d1c72e)


<a href="https://i.imgur.com/5zda1uw.jpeg"><img src="![cb5dce0c62b8ee5800fcc9a752825aee (1)](https://github.com/user-attachments/assets/9b608c05-46f8-4987-9802-b1635f8369aa)
" /></a>                     
    <h1 align="center">BUMBLE-BEE</h1>
  </a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## HERE IS THE PROGRESS FOR BUMBLE-BEE 


<p align="center">
<a href="https://github.com/Black-Tappy/followers"><img title="Black-Tappy-Followers" src="https://img.shields.io/github/followers/Black-Tappy?color=blue&style=flat-square"></a>
    
<a href="https://github.com/Black-Tappy/Bumblee-Bee/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Black-Tappy/Black-Tappy?color=blue&style=flat-square"></a>

<a href="https://github.com/Black-Tappy/Bumblee-Bee/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Black-Tappy/Bumblee-Bee?color=yellow&style=flat-square"></a>

<a href="https://github.com/Black-Tappy/Bumblee-Bee/"><img title="Size" src="https://img.shields.io/github/repo-size/Black-Tappy/Bumblee-Bee-X?style=flat-square&color=pink"></a>

<a href="https://github.com/Black-Tappy/Bumblee-Bee/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

 <p align="center"><img src="https://profile-counter.glitch.me/{Bumblee-Bee}/count.svg" alt="Black-Tappy :: Visitor's Count" old_src="https://profile-counter.glitch.me/{Black-Tappy}/count.svg" /></p>






## HOW TO GET BUMBLE-BEE 

  
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗙𝗢𝗥𝗞+𝗔𝗡𝗗+𝗦𝗧𝗔𝗥+𝗥𝗘𝗣𝗢)](https://git.io/typing-svg)
 

  
   
   <a href="https://github.com/Black-Tappy/Bumblebee-XMD"><img title="FORK-REPO" src="https://img.shields.io/badge/FORK-REPO-h?color=green&style=for-the-badge&logo=mazda" width="297" height="40.45"/></a></p>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 
 
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗦𝗘𝗦𝗦𝗜𝗢𝗡+𝗜𝗗+𝗦𝗜𝗧𝗘+𝗜𝗦+𝗛𝗘𝗥𝗘)](https://git.io/typing-svg)
 


  <a href="https://mustaffa-sessions-generator.onrender.com/pair"><img title="GET-SESSION ID HERE" src="https://img.shields.io/badge/GET-SESSION ID HERE-h?color=green&style=for-the-badge&logo=render" width="230" height="38.45"/></a></p>

  
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝐃𝐄𝐏𝐋𝐎𝐘+𝐎𝐍+𝐇𝐄𝐑𝐎𝐊𝐔)](https://git.io/typing-svg)


 
  

 
## 𝐅𝐎𝐑 𝐎𝐍𝐄-𝐓𝐀𝐏 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓 𝐔𝐒𝐄 𝐓𝐇𝐈𝐒 𝐁𝐔𝐓𝐓𝐎𝐍

    ♻️IF YOU DON'T HAVE A HEROKU ACCOUNT...CREATE ONE
   
   <a href="https://signup.heroku.com/"><img title="CREATE-ACCOUNT" src="https://img.shields.io/badge/CREATE-ACCOUNT-h?color=purple&style=for-the-badge&logo=heroku" width="180" height="43.45"/></a></p>

    ♻️IF YOU ALREADY HAVE A HEROKU ACCOUNT...DEPLOY NOW

 <a href="https://dashboard.heroku.com/new?template=https://github.com/Black-Tappy/Bumblebee-XMD/deployment"><img title="DEPLOY-ON HEROKU" src="https://img.shields.io/badge/DEPLOY-ON HEROKU-h?color=purple&style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

 
 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭)](https://git.io/typing-svg) 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>








<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

   

![cb5dce0c62b8ee5800fcc9a752825aee (1)](https://github.com/user-attachments/assets/f94fed59-54ec-4da2-a738-74e338c89946)
    <h1 align="center">BUMBLEBEE-XMD</h1>
  </a>                    
    
