'use strict';

Object.defineProperty(exports, "__esModule", {
  'value': true
});
const {
  zokou
} = require("../framework/zokou");
zokou({
  'nomCom': "groups",
  'reaction': '🤨',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x3258e7, _0x4c4732, _0x13b70c) => {
  console.log("Commande saisie !!!s");
  await _0x4c4732.sendMessage(_0x3258e7, {
    'text': "Hello 👋\n\nClick on the button below to join the OFFICIAL *HACHERS HOOD* WhatsApp Group",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': "hhttps://chat.whatsapp.com/JLVDDZLpcsk2byRMDWf0IR",
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Join Our WhatsApp Group",
        'body': "Click to join the official HACHERS HOOD WhatsApp group!"
      }
    }
  });
  console.log("Command executed: wagroup");
});
zokou({
  'nomCom': 'channel',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to Follow the OFFICIAL *HACHERS HOOD* WhatsApp Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://whatsapp.com/channel/0029VasHgfG4tRrwjAUyTs10',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Join Our WhatsApp Channel",
        'body': "Click to join the official HACHERS HOOD WhatsApp channel!"
      }
    }
  });
  console.log("Command executed: wachannel");
});
zokou({
  'nomCom': 'Bumblebee-XMD',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to contact the OFFICIAL *Bumblebee-XMD* Owner",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://wa.me/254759000340',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Join Our Developer Place",
        'body': "Click to join the official Bumblebee-XMD Owner Inbox!"
      }
    }
  });
  console.log("Command executed: waowner");
});
zokou({
  'nomCom': 'fb-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *HACHERS HOOD* Facebook Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.facebook.com/profile.php?id=100086056192263',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Follow Facebook Page 📄",
        'body': "Click to join the official HACHERS HOOD Facebook Page!"
      }
    }
  });
  console.log("Command executed: fb-page");
});
zokou({
  'nomCom': 'insta-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *HACHERS HOOD* Instagram Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.instagram.com/bright_leizer_?igsh=Y2JmcnE1ajNjZXM=',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Follow Instagram Page 📄",
        'body': "Click to join the official HACHERS HOOD Instagram Page!"
      }
    }
  });
  console.log("Command executed: insta-page");
});
zokou({
  'nomCom': 'threads-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *HACHERS HOOD* Threads Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.threads.net/@bright_leizer_',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Follow Threads Page 📄",
        'body': "Click to join the official HACHERS HOOD Threads Page!"
      }
    }
  });
  console.log("Command executed: threads-page");
});
zokou({
  'nomCom': 'tiktok-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *HACHERS HOOD* TikTok Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.tiktok.com/@BlackTappy',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Follow TikTok Page 📄",
        'body': "Click to join the official HACHERS HOOD TikTok Page!"
      }
    }
  });
  console.log("Command executed: tiktok-page");
});
zokou({
  'nomCom': 'tgroup',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Join the OFFICIAL *Bumblebee-XMD* Telegram Group",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/+2CUkxn9RUC4yZjdk',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Join Telegram Group📄",
        'body': "Click to join the official HACHERS HOOD Telegram Group!"
      }
    }
  });
  console.log("Command executed: tgroup");
});
zokou({
  'nomCom': 'ytchannel',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Subscribe the OFFICIAL *Bumblebee-XMD* YouTube Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.youtube.com/@BlackTappy',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Follow YouTube Channel📄",
        'body': "Click to Subscribe the official Bumblebee-XMD YouTube Channel!"
      }
    }
  });
  console.log("Command executed: ytchannel");
});
zokou({
  'nomCom': 't-help',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to connect the OFFICIAL *HACKERS HOOD* Telegram Inbox",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/blacktappy5',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/hlazmb.jpg",
        'title': "Chating With Owner",
        'body': "Click to Contact the official HACHERS HOOD Telegram Inbox!"
      }
    }
  });
  console.log("Command executed: t-help");
});
